

from django.conf.urls import url

from . import views

# bookstore/urls.py
# 创建子路由规则
urlpatterns = [
]

