from django.shortcuts import render

# Create your views here.


# bookstore/views.py

from . import models
from django.http import HttpResponse
def homepage(request):
    return render(request, 'index.html')

def new_book(request):
    if request.method == 'GET':
        return render(request, 'new_book.html')
    elif request.method == 'POST':
        t = request.POST.get('title', '')
        pub = request.POST.get('pub', '')
        price = request.POST.get('price', '0')
        m_price = request.POST.get('market_price', '0')
        # 方法1
        # abook = models.Book.objects.create(
        #     title = t,
        #     pub = pub,
        #     price = price,
        #     market_price = m_price
        # )
        # 方法2
        abook = models.Book(price=price)
        abook.title = t  # 修改属性
        abook.pub = pub
        abook.market_price = m_price
        abook.save()  # 存存提交
        return HttpResponse('添加成功')


def list_books(request):
    # 从模型中取数据
    books = models.Book.objects.all()
    return render(request, 'book_list.html', locals())

def filter_books(request):
    # 查出清华大学出版社的全部图书
    books = models.Book.objects.filter(pub='清华大学出版社')
    # 两个条件为与的关系
    # books = models.Book.objects.filter(pub='清华大学出版社',
    #                                    id=6)

    # books = models.Book.objects.filter(price__gte=50)
    books = models.Book.objects.order_by('-price')

    return render(request, 'book_list.html', locals())


# 路由: /bookstore/test_f/10   up---> 10
def test_f(request, up):
    '''up代表涨价的幅度'''
    books = models.Book.objects.all()
    # 用循环遍历每个对象操作涨十元
    # for book in books:
    #     p = float(book.market_price)
    #     p += float(up)
    #     book.market_price = p
    #     book.save()
    # 用F函数
    from django.db.models import F
    books.update(market_price=F('market_price')-float(up))
    return HttpResponse("整体涨价:%s元" % up)

def one2one_init(request):
    author1 = models.Author.objects.create(
            name='王老师', age=28
        )
    wife1 = models.Wife.objects.create(
        name='王夫人', author=author1)

    author2 = models.Author.objects.create(
        name='吕泽老师', age=31, email='lvze@tedu.cn')


    return HttpResponse("一对一添加成功")









