from django.apps import AppConfig


class MystoreConfig(AppConfig):
    name = 'mystore'
