

from django.conf.urls import url

from . import views

urlpatterns = [
    url(r"^list.html", views.list),
    url(r'page1', views.list),  # /music/page1
    url(r'^index', views.index),
    #/music/index
]