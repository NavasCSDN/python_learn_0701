function myname() {
    console.log("hello world")
}
