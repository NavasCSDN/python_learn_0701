from django.apps import AppConfig


class SportConfig(AppConfig):
    name = 'sport'
