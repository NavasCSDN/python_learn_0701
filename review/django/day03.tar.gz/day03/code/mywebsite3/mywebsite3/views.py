from django.http import HttpResponse
from django.shortcuts import render

def test_form(request):
    '此视图函数用于示意form表单的提交'
    if request.method == 'GET':
        # 返回表单
        dic = dict(request.GET)
        nickname = request.GET.get('nickname','')
        print("dic=", dic)
        print('nickname=', nickname)
        return render(request, 'myform.html')
    elif request.method == 'POST':
        # 返回表单提交内容的结果
        dic = dict(request.POST)
        print("POST提交的结果是：",dic)
        fav = request.POST.getlist('fav')
        print("fav=", fav)
        return HttpResponse("没有结果")


def page1(request):
    return render(request, 'page1.html')













