from django.shortcuts import render

# Create your views here.

# 此文件是bookstore/views.py

from django.http import HttpResponse

def homepage(request):
    return HttpResponse("图书列表首页")

def add_book(request):
    # 路由/book/add?title='C++'&pub='清华大学出版社'
    if request.method == 'GET':
        # 添加书
        title = request.GET.get('title','noname')
        publish = request.GET.get('pub', 'xxx')
        # 第一种创建方式
        from . import models
        models.Book.objects.create(title=title,
                                   pub=publish)
        return HttpResponse('OK')





