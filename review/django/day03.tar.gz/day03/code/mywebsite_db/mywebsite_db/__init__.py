
# mywebsite_db/__init__py

import pymysql

pymysql.install_as_MySQLdb()