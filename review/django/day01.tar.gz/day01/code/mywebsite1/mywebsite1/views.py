
from django.http import HttpResponse
from django.http import HttpResponseNotFound


def page1(request):
    print("Page1被调用！")
    return HttpResponse("这是Page1页")


def page2(request):
    html = '''
    <html>
    <head><title>这是页面2</title></head>
    <body>
        <h1> 这是 H1</h1>
        <h2 style="color:red;">
          这是 H2我是红色的
        </h2>
    </body>
    </html>
    '''
    return HttpResponse(html)

def page3(request):
    return HttpResponse("这是Page3")


def homepage(request):
    return HttpResponse("这是首页")


def page_year(request, y):
    html = "参数是：" + y
    print(type(y))
    return HttpResponse(html)


def birthday(request, y, m, d):
    html = "生日：" + y + "年" + m + '月' + d + '日'
    return HttpResponse(html)


def test(request, y):
    return HttpResponse("年"+ y)


def person(request, name, age):
    html = "<h1>姓名：" + name + "</h1>"
    html += "<h1>年龄：" + age + "</h1>"
    return HttpResponse(html)

def add(request, a, b):
    a = int(a)
    b = int(b)
    c = a + b
    html = '结果：%d' % c
    return HttpResponse(html)


def test_request(request):
    print('request.path=', request.path)
    print("request.method=", request.method)
    return HttpResponse("请求OK")


def test_request2(request):
    # 重定向到 /page2
    from django.http import HttpResponseRedirect
    return HttpResponseRedirect("https://www.jd.com")
    # return HttpResponseNotFound("没找到！")


def test_get(request):
    # value_a = request.GET['a']
    value_a = request.GET.get('a', '没有值')
    print("value_a=", value_a)
    html = " 值为：" + value_a
    for k in request.GET:
        print("键：", k, '值', request.GET[k])
    return HttpResponse("GET请求成功" + html)

def birth(request):
    if request.method == 'GET':
        year = request.GET.get("year", '0000')
        month = request.GET.get('month', '1')
        day = request.GET.get('day', '1')
        html = '生日是：' + year + "年："\
               + month + '月' + day + '日'
        return HttpResponse(html)


def search(request):
    html = '''
    <html>
    <head>
        <title>搜索</title>
        <meta charset="utf-8">
    </head>
    <body>
        <form method="POST" action="/search">
        <input name="sss" type="text">
        <input type="submit">
        </form>
    </body>
    </html>
    '''
    if request.method == 'GET':
        return HttpResponse(html)
    elif request.method == 'POST':
        sss = request.POST['sss']
        return HttpResponse('您正在POST提交 sss='+ sss)
    else:
        return HttpResponse("其它方式提交")






