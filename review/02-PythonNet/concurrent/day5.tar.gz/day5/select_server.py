"""
IO多路复用ｓｅｌｅｃｔ实现多客户端通信
重点代码
"""

from socket import *
from select import select

#　设置套接字为关注ＩＯ
s = socket()
s.setsockopt(SOL_SOCKET,SO_REUSEADDR,1)
s.bind(('0.0.0.0',8888))
s.listen(5)

# 设置关注的ＩＯ
rlist = [s]
wlist = []
xlist = []

while True:
    #　监控ＩＯ的发生
    rs,ws,xs = select(rlist,wlist,xlist)
    # 遍历三个返回值列表，判断哪个ＩＯ发生
    for r in rs:
        #　如果是套接字就绪则处理链接
        if r is s:
            c,addr = r.accept()
            print("Connect from",addr)
            rlist.append(c) #　加入新的关注ＩＯ
        else:
            data = r.recv(1024)
            if not data:
                rlist.remove(r)
                r.close()
                continue
            print(data.decode())
            # r.send(b'OK')
            #　希望我们主动处理这个ＩＯ
            wlist.append(r)

    for w in ws:
        w.send(b'Ok,Thanks')
        wlist.remove(w)
    for x in xs:
        pass





