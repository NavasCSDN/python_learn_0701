import os
import sys

# os._exit(1) #　进程退出

sys.exit("进程退出")

print("Process exit")