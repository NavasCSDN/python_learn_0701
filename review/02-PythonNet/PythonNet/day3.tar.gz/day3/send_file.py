from socket import *

s = socket()
s.connect(('127.0.0.1',8888))

f = open('timg.gif','rb')

#　读取内容进行发送
while True:
    data = f.read(1024) # 字节串
    if not data:
        break
    s.send(data)

f.close()
s.close()