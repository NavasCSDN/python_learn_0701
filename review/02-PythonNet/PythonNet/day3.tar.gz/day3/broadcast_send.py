#　广播发送

from socket import *
from time import sleep

# 广播地址
dest = ('172.40.91.255',9999)

s = socket(AF_INET,SOCK_DGRAM)

s.setsockopt(SOL_SOCKET,SO_BROADCAST,1)

data = """
    **********************
     5.8  北京　　初夏
     喜欢夏天，但你比夏天更加明媚
    **********************
"""

while True:
    sleep(2)
    s.sendto(data.encode(),dest)

s.close()



