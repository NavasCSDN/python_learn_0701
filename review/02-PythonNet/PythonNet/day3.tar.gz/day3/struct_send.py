from socket import *
import struct

#　接收端地址
ADDR = ('127.0.0.1',8888)

#　规定数据格式
st = struct.Struct('i32sif')

s = socket(AF_INET,SOCK_DGRAM)

while True:
    print("=================================")
    id = int(input("ID:"))
    name = input("NAME:").encode()
    age = int(input("AGE:"))
    score = float(input("SCORE:"))

    #　数据打包
    data = st.pack(id,name,age,score)

    s.sendto(data,ADDR)

s.close()


