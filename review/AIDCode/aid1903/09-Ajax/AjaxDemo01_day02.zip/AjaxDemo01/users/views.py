from django.http import HttpResponse
from django.shortcuts import render
from .models import *
import json
from django.core import serializers

# Create your views here.
def register_views(request):
    return render(request,'register.html')

def checkuname(request):
  #1.获取前端传递过来的参数-uname
  uname = request.GET['uname']
  #2.查询数据库中user表uname列中是否存在 uname 对应的值
  users = User.objects.filter(uname=uname).all()
  #3.根据查询结果给出响应
  if users:
    return HttpResponse("1")
  
  return HttpResponse("0")

def reguser(request):
  #1.接收前端传递过来的参数
  uname = request.POST['uname']
  upwd = request.POST['upwd']
  nickname = request.POST['nickname']
  #2.将数据保存进数据库
  try:
    User.objects.create(uname=uname,upwd=upwd,nickname=nickname)
    return HttpResponse("注册成功")
  except Exception as ex:
    return HttpResponse("注册失败")


def query_users(request):
  return render(request,'query.html')

def query_server(request):
  users = User.objects.all()
  # 1_wangwc_wangwc_TeacherWang|2_lvze_maria_吕泽玛利亚
  msg = ""
  for u in users:
    msg +="%s_%s_%s_%s|" % (u.id,u.uname,u.upwd,u.nickname)
  msg = msg[0:-1]

  return HttpResponse(msg)

def jso(request):
  return render(request,'jso.html')

def json_views(request):
  return render(request,'json.html')

def json_server(request):
  #1.通过字典来模拟单个对象
  dic = {
    'uname':'LvzeMaria',
    'uage': 30,
    'ugender':'male',
  }
  jsonStr = json.dumps(dic)

  #2.通过列表+字典模拟多个对象
  users = [
    {
      "uname":"sanfeng.zhang",
      "uage": 89
    },
    {
      "uname":"张无忌",
      "uage":60
    }
  ]

  #3.读取User实体中所有的数据并转换成JSON格式的字符串
  users = User.objects.all()
  str = serializers.serialize('json',users)
  return HttpResponse(str)





