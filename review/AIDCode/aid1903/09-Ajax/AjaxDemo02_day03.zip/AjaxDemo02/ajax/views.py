import json

from django.http import HttpResponse
from django.shortcuts import render

# Create your views here.
def load_views(request):
  return render(request,'01-load.html')

def server01(request):
  #接收前端传递过来的参数
  uname = request.POST['uname']
  uage= request.POST['uage']
  return render(request,'01-server.html',locals())

def server02(request):
  dic = {
    'uname':'Uzumaki Naruto',
    'uage': 16
  }

  jsonStr = json.dumps(dic)
  return HttpResponse(jsonStr)

def get_views(request):
  return render(request,'02-get.html')

def post_views(request):
  return render(request,'03-post.html')

def server03(request):
  uname = request.POST['uname']
  uage = request.POST['uage']
  ugender = request.POST['ugender']
  msg = "姓名:%s,年龄:%s,性别:%s" % (uname,uage,ugender)
  return HttpResponse(msg)

def server04(request):
  list = [
    {
      "cname":"Python基础",
      "teacher":"QTX"
    },
    {
      "cname":"Web基础",
      "teacher":"ZHMM"
    }
  ]
  return HttpResponse(json.dumps(list))


def ajax_views(request):
  return render(request,'04-ajax.html')

def cross_views(request):
  return render(request,'05-cross.html')

def server05(request):
  return HttpResponse("这是server05响应回来的内容")


def js_views(request):
  return render(request,'06-js.html')

def server06(request):
  #1.接收前端传递过来的callback参数值
  cb = request.GET['callback']
  return HttpResponse(cb+"('这是server06响应的内容')")














