def fun():
    print("Hello world")
    fun()

fun()