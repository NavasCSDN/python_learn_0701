from fake_useragent import UserAgent

ua = UserAgent()
print(ua.random)