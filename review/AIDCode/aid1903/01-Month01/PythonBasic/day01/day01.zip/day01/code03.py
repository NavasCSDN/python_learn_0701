"""
    变量
"""

# 变量名 = ....
a = "你好"
b = "世界"
a = "太美好"
c = b + a

class_name = "1903"
stu_name = "zs"
class_name = class_name + stu_name









