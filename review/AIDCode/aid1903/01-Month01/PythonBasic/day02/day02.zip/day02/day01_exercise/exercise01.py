"""
    排除错误
"""
name = input("请输入姓名:")
age = input("请输入年龄:")
print("输入的是:"+name)
print("年龄是:"+age)