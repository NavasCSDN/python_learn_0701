"""
    算数运算符
    比较运算符
"""

num01 = 5
num02 = 2.1
print(num01 + num02)
# %作用1:判断一个数能否被另外一个数整除
print(num01 % 2 == 0)
# %作用2: 获取个位
print(67 % 10)

num03 = 1
print(num03 + 1)
print(num03) # 1

num04 = 800
# 修改num04
num04 = num04 + 1
num04 += 1




















