
from django.http import HttpResponse


def shebao(request):
    html = '''
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
    <form action="/shebao" method='POST'>
        <div>
        请输入基数 <input type=input name="income">
        </div>
        <div>
        请输选择户口
        <select name="is_city">
            <option value ="1">城镇户口</option>
            <option value ="0">农村户口</option>
        </select>
        </div>
        <input type="submit">
    </form>
    '''


    html_end = '''
</body>
</html>
'''
    if request.method == 'GET':
        return HttpResponse(html+ html_end)
    elif request.method == 'POST':
        base = request.POST.get('income', '0')
        base = base if base else '0'
        base = float(base)
        is_city = request.POST.get('is_city')
        html_table = '''
        <table>
            <tr>
            <th style="text-align:center">项目</th>
            <th style="text-align:center">个人缴纳</th>
            <th style="text-align:center">单位缴纳</th>
            </tr>
            <tr>
            <td style="text-align:center">养老保险：</td>
        '''
        html_table += '<td style="text-align:center">%d元</td>' % (base * 0.08)
        html_table += '<td style="text-align:center">%d元</td>' % (base * 0.19)
        html_table += '''
            </tr>
        </table>
        '''

        return HttpResponse(html + html_table + html_end)



