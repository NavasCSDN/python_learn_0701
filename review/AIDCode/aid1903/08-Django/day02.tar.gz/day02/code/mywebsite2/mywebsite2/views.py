
from django.http import HttpResponse

# 导入loader
from django.template import loader
from django.shortcuts import render


def page1_template(request):
    '''此函数用于测试模板的加载的渲染'''
    # 第一种方式
    # t = loader.get_template("page1.html")
    # html = t.render()  # 用模块渲染生成html字符串
    # print(html)
    #
    # return HttpResponse(html)

    # 第二种方式
    return render(request, 'page1.html')

class Dog:
    def __init__(self, k, c):
        self.kinds = k  # 种类
        self.color = c  # 颜色
    def info(self):
        return self.color + "的" + self.kinds + '狗'

def page2_render(request):
    d = {"name":'魏老师',
         'age': 35,
         'favorite': ['看书', '看电影'],
         'friend':{'name':"小张",'age':25},
         'pet': Dog('京巴', '白色')
         }
    # 第一种传参方式
    # t = loader.get_template("page2.html")
    # html = t.render(d)
    # return HttpResponse(html)
    # 第二种传参方式
    return render(request, 'page2.html', d)



def test_tag(request):
    dic = {
        'name': '魏老师',
        'has_car': False,
        'age': 35,
        'fav': ['乒乓球', '电影', '蓝球', '写代码']
    }
    return render(request, 'page3.html', dic)

def page4(request):
    string = 'Welcome to Beijing!'
    a = "<span>hello</span>"
    print("locals()=", locals())
    return render(request, 'page4.html', locals())

def homepage(request):
    return render(request, 'base.html')


def sport_homepage(request):
    return render(request, 'sport.html')


def pages(request):
    return render(request, 'pages.html')


def person(request, name):
    return render(request, 'person.html',
                  locals())


def info(request, name):
    s = name + "的详细信息"
    return HttpResponse(s)











